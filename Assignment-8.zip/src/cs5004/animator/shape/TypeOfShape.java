/* CS 5004 - Easy Animator
 * Vandita Attal & Swapnil Mittal
 */

package cs5004.animator.shape;

/**
 * This is an enum class of the two different types of shapes.
 */
public enum TypeOfShape {
  ELLIPSE, RECTANGLE
}
