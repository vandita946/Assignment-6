/* CS 5004 - Easy Animator - Model
 * Vandita Attal & Swapnil Mittal
 */

package cs5004.animator.animation;

/**
 * This is an enum class representing types of animations.
 */
public enum TypeOfAnimation {
  MOVE, SCALE, COLOR
}


